#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include "ArbolB.h"
#include "ArbolBB.h"

using namespace std;

void ArbolB::splitChild(NodoB* parent, int index, NodoB* child) {
    NodoB* newNodeB = new NodoB(MaxLlaves, child->esHoja);
    newNodeB->Clientes.insert(newNodeB->Clientes.begin(), child->Clientes.begin() + t, child->Clientes.end());
    child->Clientes.erase(child->Clientes.begin() + t, child->Clientes.end());
    if (!child->esHoja) {
        newNodeB->Llaves.insert(newNodeB->Llaves.begin(), child->Llaves.begin() + t, child->Llaves.end());
        child->Llaves.erase(child->Llaves.begin() + t, child->Llaves.end());
    }
    parent->Llaves.insert(parent->Llaves.begin() + index + 1, newNodeB);
    parent->Clientes.insert(parent->Clientes.begin() + index, child->Clientes.back());
    child->Clientes.pop_back();
}

void ArbolB::insertNonFull(NodoB* node, Cliente* key) {
    int i = node->Clientes.size() - 1;
    if (node->esHoja) {
        node->Clientes.push_back(key);
        //sort(node->Clientes.begin(), node->Clientes.end(), key.CompareClients);
        return;
    }
    while (i >= 0 && node->Clientes[i]->numCliente > key->numCliente) {
        i--;
    }
    if (node->Llaves[i + 1]->Clientes.size() == MaxLlaves) {
        splitChild(node, i + 1, node->Llaves[i + 1]);
        if (node->Clientes[i + 1]->numCliente < key->numCliente) {
            i++;
        }
    }
    insertNonFull(node->Llaves[i + 1], key);
}

void ArbolB::printInOrder(NodoB* node) {
    int i;
    for (i = 0; i < node->Clientes.size(); i++) {
        if (!node->esHoja) {
            printInOrder(node->Llaves[i]);
        }
        cout << node->Clientes[i]->numCliente << ", " << node->Clientes[i]->nombre << " ";
    }
    if (!node->esHoja) {
        printInOrder(node->Llaves[i]);
    }
}

Cliente* ArbolB::buscarCliente(NodoB* node, int numCliente) {
    int i = 0;
    while (i < node->Clientes.size() && numCliente > node->Clientes[i]->numCliente) {
        i++;
    }
    if (i < node->Clientes.size() && numCliente == node->Clientes[i]->numCliente) {
        return node->Clientes[i];
    }
    if (node->esHoja) {
        return NULL;
    }
    return buscarCliente(node->Llaves[i], numCliente);
}

void ArbolB::cargarCliente(ArbolBB* ArbolPaises, ArbolBB* ArbolCuidades) {

    string pDireccion = "Clientes.txt";

    // Crear objeto ifstream para leer el archivo en la dirección especificada
    ifstream archivo;
    archivo.open(pDireccion);

    // Verificar si se pudo abrir el archivo
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo" << endl;
        return;
    }

    // String para almacenar cada línea del archivo
    string linea;

    // Recorrer cada línea del archivo
    while (getline(archivo, linea)) {

        size_t pos1 = linea.find(';');
        size_t pos2 = linea.find(';', pos1 + 1);
        size_t pos3 = linea.find(';', pos2 + 1);
        size_t pos4 = linea.find(';', pos3 + 1);
        size_t pos5 = linea.find(';', pos4 + 1);
        size_t pos6 = linea.find(';', pos5 + 1);
        size_t pos7 = linea.find(';', pos6 + 1);
        size_t pos8 = linea.find(';', pos7 + 1);
        size_t pos9 = linea.find(';', pos8 + 1);
        size_t pos10 = linea.find(';', pos9 + 1);

        // Crear un nuevo objeto Nodo para almacenar los datos de la canción
        Cliente* aux = new Cliente();

        // Separar la línea en 13 parte y los asigna cada parte a un atributo
        aux->numCliente = stoi(linea.substr(0, pos1));
        aux->nombre = linea.substr(pos1 + 1, pos2 - pos1 - 1);
        aux->direccion = linea.substr(pos2 + 1, pos3 - pos2 - 1);
        aux->codPais = stoi(linea.substr(pos3 + 1, pos4 - pos3 - 1));
        aux->codCuidad = stoi(linea.substr(pos4 + 1, pos5 - pos4 - 1));
        aux->telefono = stoi(linea.substr(pos5 + 1, pos6 - pos5 - 1));
        aux->dia = stoi(linea.substr(pos6 + 1, pos7 - pos6 - 1));
        aux->mes = stoi(linea.substr(pos7 + 1, pos8 - pos7 - 1));
        aux->anio = stoi(linea.substr(pos8 + 1, pos9 - pos8 - 1));
        aux->descuento = stoi(linea.substr(pos9 + 1, pos10 - pos9 - 1));
        aux->saldo = stoi(linea.substr(pos10 + 1));

        if (ArbolPaises->buscarPais(aux->codPais) == NULL) {
            continue;
        }

        if (ArbolCuidades->buscarCiudad(aux->codCuidad) == NULL) {
            continue;
        }

        if (buscarCliente(aux->numCliente) == NULL) {
            insertarCliente(aux);
        }
    }

    // Cerrar el archivo
    archivo.close();
}

void ArbolB::insertarCliente(Cliente* key) {
    if (raiz == NULL) {
        raiz = new NodoB(MaxLlaves, true);
        raiz->Clientes.push_back(key);
        return;
    }
    if (raiz->Clientes.size() == MaxLlaves) {
        NodoB* newRoot = new NodoB(MaxLlaves, false);
        newRoot->Llaves.push_back(raiz);
        splitChild(newRoot, 0, raiz);
        raiz = newRoot;
    }
    insertNonFull(raiz, key);
}

void ArbolB::mostrarClientes() {
    if (raiz == NULL) {
        return;
    }
    printInOrder(raiz);
    cout << endl;
}

Cliente* ArbolB::buscarCliente(int numCliente) {
    if (raiz == NULL) {
        return NULL;
    }
    return buscarCliente(raiz, numCliente);
}
